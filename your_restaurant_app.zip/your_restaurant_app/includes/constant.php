<?php 

    $var_personal_token = "VLfytVJ5JnU6Yx7zhoX6yPclHgAFMK9Z";
    $var_item_id = 18273140;

?>