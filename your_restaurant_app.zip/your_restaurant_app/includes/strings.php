<?php

$app_name = 'Your Restaurant App';
$app_version = 'Version 3.1.0';
$app_copyright = 'Copyright © 2024 Solodroid Developer';

?>